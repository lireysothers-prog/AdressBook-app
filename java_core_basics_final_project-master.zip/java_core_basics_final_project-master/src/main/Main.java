public class Main {
    public static void main(String[] args) {
        MenuNavigator menuNavigator = new MenuNavigator();
        menuNavigator.start();
    }
}
